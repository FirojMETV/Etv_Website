import React from 'react'
import playstore from "/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/playstore.png";
import apple from "/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/apple.png";
import { BsFacebook, BsInstagram, BsTwitter } from 'react-icons/bs'
import './footer.css'
const Footer = () => {
    return (
        <>
            <div className='Footer'>
                <div className='Connect'>
                    <div className='download'>
                        <ul className='leftItem'>
                            <li>
                                <text className='text'>Download App</text>
                            </li>
                            <li>
                                <img src={playstore} className='playstore' />
                            </li>
                            <li>
                                <img src={apple} className='apple' />
                            </li>
                        </ul>
                    </div>
                    <div className='Follow'>
                        <ul className='RightItem'>
                            <li>
                                <text className='Contact'>Connect with us</text>


                                <a className='facebook' >
                                    <BsFacebook href='' />
                                </a>

                                <a className='insta' >
                                    <BsInstagram />
                                </a>

                                <a className='twitt'>
                                    <BsTwitter />
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className='aboutus'>
                    <ul className='aboutText'>
                        <a> ABOUT US |</a>
                        <a> CONTACT US |</a>
                        <a> PRIVACY POLICY | </a>
                        <a>TERMS & CONDITIONS | </a>
                        <a> FAQ |</a>
                        <a> FEEDBACK |</a>
                        <a>  SUBSCRIPTIONS </a>
                    </ul>
                </div>
                <div className='copyright'>
                    <text>
                        © Eenadu Television Pvt. Ltd. 2023. All Rights Reserved
                    </text>
                </div>
            </div>
        </>
    )
}

export default Footer


