// import React, { useState } from 'react';
// import { FaSearch, FaUser, FaBars } from 'react-icons/fa';
// import './news.css';
// import Logo from '/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/et.jpg'

// function News() {
//   const [showMenu, setShowMenu] = useState(false);

//   const handleMenuToggle = () => {
//     setShowMenu(!showMenu);
//   }

//   return (
//     <>
//       <nav className='main-nav'>
//         <div className="logo">
//           <img src={Logo}  />
//         </div>
//         <div className='menu-link'>
//           <ul className={`header-nav ${showMenu ? 'show-menu' : ''}`}>
//             <li>Home</li>
//             <li>About</li>
//             <li>TV Shows</li>
//             <li>Live TV</li>
//             <li>Food</li>
//             <li>Health</li>
//             <li>Movies</li>
//             <li>News</li>

//           </ul>
//         </div>
//         <div className="social-media">
//           <ul className='socila-media-desktop'>
//             <li>
//               <a><FaSearch className="search-icon" />
//               </a>
//             </li>
//             <li>
//               <a> <FaUser className="user-icon" />
//               </a>
//             </li>
//             <li>
//               <a><FaBars className="menu-icon" onClick={handleMenuToggle} />
//               </a>
//             </li>
//           </ul>
//         </div>
//       </nav>
//     </>
//   );
// }

// export default News;



// import React, { useState } from "react";
// import logo from '/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/et.jpg';
// import sub from '/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/subscribe.png';
// import "./news.css";
// import { FaSearch, FaUser, FaBars } from 'react-icons/fa';

// function Header() {
//   const [showMenu, setShowMenu] = useState(false);

//   function handleMenuClick() {
//     setShowMenu(!showMenu);
//   }

//   return (
//     <div className="header">
//       <div className="header__left">
      
//           <FaBars   className="menu" onClick={handleMenuClick}/>
      
//         <img src={logo} alt="Logo" className="header__logo" />
//       </div>
//       <div className="header__center">
//         <ul className={`header__menu ${showMenu ? "show" : ""}`}>
//           <li className="header__menu-item"><a href="#">Home</a></li>
//           <li className="header__menu-item"><a href="#"> TV Shows</a></li>
//           <li className="header__menu-item"><a href="#">Live TV</a></li>
//           <li className="header__menu-item"><a href="#">News </a></li>
//           <li className="header__menu-item"><a href="#">Movies</a></li>
//           <li className="header__menu-item"><a href="#">Food</a></li>
//           <li className="header__menu-item"><a href="#">Health</a></li>
//         </ul>
        
//       </div>
//       <div className="header__right">
//         <i >
//           <img src={sub}  className="sub"/>
//         </i>
//         <i className="fas fa-search">
//           <FaSearch/>
//         </i>
//         <i className={`header__menu ${showMenu ? "" : ""}`}>
//           <FaUser/>
//         </i>
      
//       </div>
//     </div>
//   );
// }

// export default Header;

import React, { useState } from "react";
import logo from "/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/et.jpg";
import sub from "/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/subscribe.png";
import "./news.css";
import { FaSearch, FaUser, FaBars } from "react-icons/fa";
import { Carousel } from "react-bootstrap";

function Header() {
  const [showMenu, setShowMenu] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  function handleMenuClick() {
    setShowMenu(!showMenu);
  }

  function handleUserIconEnter() {
    setShowDropdown(true);
  }

  function handleUserIconLeave() {
    setShowDropdown(false);
  }

  return (
    <>
    <div className="header">
      <div className="header__left">
        <FaBars className="menu" onClick={handleMenuClick} />
        <img src={logo} alt="Logo" className="header__logo" />
      </div>
      <div className="header__center">
        <ul className={`header__menu ${showMenu ? "show" : ""}`}>
          <li className="header__menu-item">
            <a href="#">Home</a>
          </li>
          <li className="header__menu-item">
            <a href="#"> TV Shows</a>
          </li>
          <li className="header__menu-item">
            <a href="#">Live TV</a>
          </li>
          <li className="header__menu-item">
            <a href="#">News </a>
          </li>
          <li className="header__menu-item">
            <a href="#">Movies</a>
          </li>
          <li className="header__menu-item">
            <a href="#">Food</a>
          </li>
          <li className="header__menu-item">
            <a href="#">Health</a>
          </li>
        </ul>
      </div>
      <div className="header__right">
        <i>
          <img src={sub} className="sub" />
        </i>
        <i className="fas fa-search">
          <FaSearch />
        </i>
        <div
          className={`header__menu ${showMenu ? "" : ""}`}
          onMouseEnter={handleUserIconEnter}
          onMouseLeave={handleUserIconLeave}
        >
          <FaUser />
          {showDropdown && (
            <ul className="user-dropdown">
              <li>
                <a href="#">Profile</a>
              </li>
              <li>
                <a href="#">Settings</a>
              </li>
              <li>
                <a href="#">Logout</a>
              </li>
            </ul>
          )}
        </div>
      </div>
    </div>
          <div>
         
          </div>
    </>
    
  );
}

export default Header;
