import React from 'react';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import { Input } from '@mui/material';

function MyForm() {
  const handleSubmit = (values, { setSubmitting }) => {
    // Perform form submission or other actions with the form values
    console.log(values);
    setSubmitting(false);
  };

  const validateForm = (values) => {
    const errors = {};

    if (!values.name) {
      errors.name = 'Name is required';
    }

    if (!values.email) {
      errors.email = 'Email is required';
    } else if (!/^\S+@\S+\.\S+$/.test(values.email)) {
      errors.email = 'Invalid email address';
    }

    if (!values.mobile) {
      errors.mobile = 'Mobile is required';
    } else if (!/^\d{10}$/.test(values.mobile)) {
      errors.mobile = 'Invalid mobile number';
    }

    return errors;
  };

  return (
    <Formik
      initialValues={{ name: '', email: '', mobile: '' }}
      validate={validateForm}
      onSubmit={handleSubmit}
    >
      <Form>
        <div>
          <label htmlFor="name">Name:</label>
          <Input type="text" id="name" name="name" />
          <ErrorMessage name="name" component="div" className="error-message" />
        </div>

        <div>
          <label htmlFor="email">Email:</label>
          <Input type="email" id="email" name="email" />
          <ErrorMessage name="email" component="div" className="error-message" />
        </div>

        <div>
          <label htmlFor="mobile">Mobile:</label>
          <Input type="text" id="mobile" name="mobile" />
          <ErrorMessage name="mobile" component="div" className="error-message" />
        </div>

        <button type="submit">Submit</button>
      </Form>
    </Formik>
  );
}

export default MyForm;
