import React, { useState } from "react";
import logo from '/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/et.jpg';
import sub from '/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/subscribe.png';
import "./navbar.css";
import { FaSearch, FaUser, FaBars } from 'react-icons/fa';
import { MdCancel } from 'react-icons/md';
import { BsFacebook } from 'react-icons/bs';
import google from '/Users/WIN/Desktop/Etvwin/etvwin/src/assets/image/google.png'
import { Button, Input } from "@mui/material";


const SignInPopup = ({ onClose }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
  };

  return (
    <div className="popup-container">
      <div className="popup-content">

        <text className='h4'>SIGN IN </text>
        <text className="close-button" onClick={onClose}>
          &#10005;
        </text>
        <form onSubmit={handleSubmit}>
          <Input
            style={{ color: "white" }}
            label="Error"
            placeholder="Email/Mobile *"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required={true}
          />

          <Input
            style={{ color: "white" }}
            type="password"
            placeholder="Password *"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required={true}
          />
          <a className="forgot">FORGOT PASSWORD ?</a>
          <div className="Sign_In"> <Button type="submit" >
            SIGN IN
          </Button>
          </div>
          <div class="divider">
            OR
          </div>
          <div className='socialmedia'>
            <a className='facebooksign' href='#'><BsFacebook size={30} color='#fff' className='facebooksign' /></a>
            <img className='googlesign' href='#' src={google} />
          </div>
          <div className="Sign_up">
            <Button style={{ color: '#ddd', backgroundColor: '#8149bf', borderRadius: 20, marginTop: 20, cursor: 'pointer' }}>SIGN UP</Button>
          </div>
        </form>

      </div>


    </div>
  );
};


function Navbar() {
  const [showMenu, setShowMenu] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const handlePopupOpen = () => {
    setShowPopup(true);
  };
  function handleMenuClick() {
    setShowMenu(!showMenu);
  }

  function handleMenuHide() {
    setShowMenu(false);
  }

  return (
    <div className="header">
      <div className="header__left">

        <FaBars className="menu" onClick={handleMenuClick} />

        <img src={logo} alt="Logo" className="header__logo" />
      </div>
      <div className="header__center">
        <ul className={`header__menu ${showMenu ? "show" : ""}`}>
          <li className="header__menu-item"><a href="#">Home</a></li>
          <li className="header__menu-item"><a href="#"> TV Shows</a></li>
          <li className="header__menu-item"><a href="#">Live TV</a></li>
          <li className="header__menu-item"><a href="#">News </a></li>
          <li className="header__menu-item"><a href="#">Movies</a></li>
          <li className="header__menu-item"><a href="#">Food</a></li>
          <li className="header__menu-item"><a href="#">Health</a></li>

        </ul>
        <div className={` ${showMenu ? "show" : ""}`} >
          {/* <a href="#" className="" >Sign In</a>
          <a href="#" className="" >Sign Out</a> */}
          <a > <MdCancel onClick={handleMenuHide} /></a>
        </div>
      </div >
      <div className="header__right">
        <i >
          <img src={sub} className="sub" />
        </i>
        <i className="fas fa-search">
          <FaSearch size={25} className="search" />
        </i>
        <i className={`header__menu ${showMenu ? "" : ""}`}>
          <i className={'dropdown'}>
            <FaUser size={24} className="dropbtn" />
            <div class="dropdown-content">
              <a href="#" className="sign"
                onClick={handlePopupOpen}
              > {showPopup && <SignInPopup onClose={() => setShowPopup(false)} />} SIGN IN</a>
              <a href="#" className="sign">SIGN OUT</a>
            </div>
          </i>
        </i>
      </div>
    </div >
  );
}



export default Navbar;


