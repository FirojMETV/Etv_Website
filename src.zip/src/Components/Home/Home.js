import React, { useEffect, useState, useRef } from "react";
import "./home.css";
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
export default function Home() {

  const [index, setIndex] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(1);

  const handleZoom = () => {
    setZoomLevel(zoomLevel + 0.02);
  };
  const Images = [
    "https://www.w3schools.com/css/img_5terre.jpg",
    "https://www.w3schools.com/css/img_forest.jpg",
    "https://www.w3schools.com/css/img_lights.jpg",
    "https://www.w3schools.com/css/img_5terre.jpg",
    "https://www.w3schools.com/css/img_forest.jpg",
    "https://www.w3schools.com/css/img_lights.jpg",
    "https://www.w3schools.com/css/img_5terre.jpg",
    "https://www.w3schools.com/css/img_forest.jpg",
    "https://www.w3schools.com/css/img_lights.jpg"
  ];

  useEffect(() => {
    // setInterval(onNext, 2000);
    setTimeout(handleTimeout, 5000);
  }, []);

  const onNext = () => {
    console.log(Images.length);

    if (index < Images.length - 1) {
      let i = index + 1;
      setIndex(i);
    } else {
      setIndex(0);
    }
  };

  const onPrev = () => {
    if (index > 0 && index < Images.length) {
      let i = index - 1;
      setIndex(i);
    } else {
      setIndex(Images.length - 1);
    }
  };

  const onJump = (i) => {
    setIndex(i);
  };

  const handleMouseMove = (event) => {
    const direction = event.clientX > window.innerWidth / 2 ? 'right' : 'left';
    if (direction === 'left') {
      setIndex((index - 1 + Images.length) % Images.length);
    } else if (direction === 'right') {
      setIndex((index + 1) % Images.length);
    }
  };

  const handleTimeout = () => {
    if (index === Images.length - 1) {
      setIndex(0);
    } else {
      setIndex(index + 1);
    }
  };

  const handleScroll = (event) => {
    const scrollLeft = event.target.scrollLeft;
    setIndex(scrollLeft / Images[0].width);
  };

  return (
    <div className="div">
      <div className="carousel"
        //  onMouseMove={handleMouseMove}
        onChange={useEffect}>
        {Images.map((item, i) =>
          i === index ? (
            <div className="carousel-item" key={i}>
              <img src={item} alt={item} draggable='false' />
            </div>

          ) : ""
        )}
        <a className="prev" onClick={onPrev}>
          &#x3c;
        </a>
        <a className="next" onClick={onNext}>
          &#x3e;
        </a>
      </div>
      <a className="carousel-dots">
        {Images.map((item, i) => (
          <text
            class="dot"
            className={`dot ${i === index ? "active" : ""}`}
            key={i}
            onClick={() => onJump(i)}
          > </text>
        ))}
      </a>
      <div className="Win">
        <div className="Item">
          <text className="TextWin">
            WIN Exclusives
          </text>
        </div>
        <div>
          <a href="#" className="More">+More</a>
        </div>
        <div className="WinItem">
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="WinImages" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="WinImages" />
  
        </div>
      </div>
      <div className="BeforeTv">
        <div className="Before">
          <text className="TextBefore">
          Before TV
          </text>
        </div>
        <div>
          <a href="#" className="More">+More</a>
        </div>
        <div className="BeforeItem">
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg"  className="BeforeImg" />
          <img src="https://www.w3schools.com/css/img_forest.jpg" className="BeforeImg" />
        </div>
      </div>
    </div>
  );
}

