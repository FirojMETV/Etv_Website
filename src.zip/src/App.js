import React from 'react'
import './app.css'
import Home from './Components/Home/Home';
import MyForm from './Components/LiveTv/LiveTv';
import News from './Components/News/News';
import Navbar from './Components/Navbar/Navbar';
import Footer from './Components/Footer/Footer';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'


const App = () => {
    return (
       
            <Router>
              <Navbar/>
              <Home/>
             <Footer/>
              {/* <MyForm/> */}
            </Router>
       

    )
}

export default App
  
